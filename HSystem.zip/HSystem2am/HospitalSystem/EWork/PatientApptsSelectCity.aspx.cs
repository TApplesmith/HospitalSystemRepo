﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EWork_PatientApptsSelectCity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }

    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string city = GridView1.SelectedRow.Cells[1].Text;

        Session.Add("CityChoice", city);

        GridView2.Visible = true;
        GridView3.Visible = false;
        GridView4.Visible = false;
        Button1.Visible = false;
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        int hospital = Convert.ToInt32(GridView2.SelectedRow.Cells[1].Text);

        Session.Add("HospitalChoice", hospital);

        GridView3.Visible = true;
        GridView4.Visible = false;
        Button1.Visible = false;

    }


    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {
        int department = Convert.ToInt32(GridView3.SelectedRow.Cells[1].Text);

        Session.Add("DepartmentChoice", department);

        GridView4.Visible = true;
        Button1.Visible = false;

    }

    protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
    {
        int doctor = Convert.ToInt32(GridView4.SelectedRow.Cells[1].Text);

        string docUN = GridView4.SelectedRow.Cells[4].Text;

        Session.Add("DoctorChoiceUsername", docUN);

        Session.Add("DoctorChoiceID", doctor);

        Button1.Visible = true;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        GridView2.Visible = false;
        GridView3.Visible = false;
        GridView4.Visible = false;
        Button1.Visible = false;
        Response.Redirect("PatientApptsSelectTime.aspx");
    }
}