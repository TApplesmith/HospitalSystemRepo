﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EWork_PatientApptsSelectTime : System.Web.UI.Page
{

    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        /*
        //using listbox to problem solve
        ListBox1.Items.Add((Convert.ToInt32(Session["DoctorChoiceID"]).ToString()));
        ListBox1.Items.Add(TextBox2.Text);
        ListBox1.Items.Add((Convert.ToDateTime(TextBox1.Text)).ToString());
        ListBox1.Items.Add(Convert.ToInt32(Session["PatientID"]).ToString());

        //grab time
        int hour = Convert.ToInt32(DropDownList1.SelectedValue);
        int min = Convert.ToInt32(DropDownList2.SelectedValue);

        ListBox1.Items.Add((new TimeSpan(hour, min, 0)).ToString());

        ListBox1.Items.Add(Session["DoctorChoiceUsername"].ToString());
        ListBox1.Items.Add(Session["Username"].ToString());

        */



       
        AppointmentTable myApp = new AppointmentTable();

        //add data to myApp = docID, description, date
        myApp.DoctorId = Convert.ToInt32(Session["DoctorChoiceID"]);
        myApp.Description = TextBox2.Text;
        myApp.AppointmentDate = Convert.ToDateTime(TextBox1.Text);

        //ADD PATIENT ID TO APPT
        myApp.PatientId = Convert.ToInt32(Session["PatientID"]);

        //grab time
        int hour = Convert.ToInt32(DropDownList1.SelectedValue);
        int min = Convert.ToInt32(DropDownList2.SelectedValue);

        myApp.AppointmentTime = new TimeSpan(hour, min, 0);

        //grab doctor username and patient username
        myApp.DoctorUserName = Session["DoctorChoiceUsername"].ToString();
        myApp.PatientUserName = Session["Username"].ToString();

        //check if appointment already exists for this date and time

        int results = (from x in dbcon.AppointmentTables
                       where x.AppointmentDate == myApp.AppointmentDate &&
                       x.AppointmentTime == myApp.AppointmentTime
                       && x.DoctorId == myApp.DoctorId
                       select x).Count();
        if (results > 0) //aka there is already an appointment in the db
        {
            //if yes...
            //do nothing and tell to do a different date/time
            Label1.Visible = true;
        }
        else //the appointment is fine to add
        {
            //if not...
            dbcon.AppointmentTables.Add(myApp);
            dbcon.SaveChanges();

            //navigate to different page
            Response.Redirect("PatientApptsConfirm.aspx");
        }
      
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
    }


    /*
    protected void TestingSubmission()
    {
        AppointmentTable myApp = new AppointmentTable();

        myApp.AppointmentDate = new DateTime(2006, 12, 1);
        myApp.AppointmentTime = new TimeSpan(1, 12, 12);
        myApp.Description = "test";
        myApp.DoctorId = 3;
        myApp.DoctorUserName = "BDees";
        myApp.PatientId = 10;
        myApp.PatientUserName = "PJans";


       // dbcon.AppointmentTables.Add(myApp);
       // dbcon.SaveChanges();
    }
    */
}