﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EWork_DoctorApptsView : System.Web.UI.Page
{
    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();

    protected void Page_Load(object sender, EventArgs e)
    {

        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }



        string username = "";

        Session.Add("PatientID", "");

        //make sure session var is set
        try
        {
            if (Session["Username"].ToString() != null)
            {
                username = Session["Username"].ToString();
            }

        }
        catch (Exception)
        {

        }


        try
        {
            //grab user that corresponds to username of current user
            DoctorTable result = (from x in dbcon.DoctorTables
                                   where x.DoctorUserName.Equals(username)
                                   select x).First();

            //Session.Add("PatientID", result.PatientId);
            Session.Add("DoctorID", result.DoctorId);
        }
        catch (Exception)
        {

        }

        //see if any appointments
        int id = Convert.ToInt32(Session["DoctorID"]);
        int appts = (from x in dbcon.AppointmentTables
                     where x.DoctorId == id
                     select x).Count();
        if (appts == 0)
        {
            Label1.Visible = true;
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //delete whatever appointment is selected

        int idOfSelectedApp = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);

        AppointmentTable app = (from x in dbcon.AppointmentTables
                                where x.AppointmentId == idOfSelectedApp
                                select x).First();

        dbcon.AppointmentTables.Remove(app);
        dbcon.SaveChanges();
        Response.Redirect("DoctorApptsView.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //send to page to grab patient for appt
        Response.Redirect("DoctorSearchPatientSelect.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Button2.Visible = true;
    }
}