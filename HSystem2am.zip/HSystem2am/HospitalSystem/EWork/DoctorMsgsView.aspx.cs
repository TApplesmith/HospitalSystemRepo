﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EWork_DoctorMsgsView : System.Web.UI.Page
{
    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }


        //see if any messages for the current patient
        string doctorUN = Session["Username"].ToString();

        int msgs = (from x in dbcon.EmailTables
                    where x.DoctorUserName == doctorUN &&
                       x.Sender != doctorUN
                    select x).Count();
        if (msgs == 0)
        {
            Label1.Visible = true;
        }

        else
        {
            //string currentUserName = Session["Username"].ToString();
            //SqlDataSource1.FilterExpression = "Sender <> " + currentUserName + "";
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Button2.Visible = true;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("PatientMsgsSend.aspx");
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        //delete whatever email is selected


        int idOfSelectedEmail = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);

        EmailTable app = (from x in dbcon.EmailTables
                          where x.EmailId == idOfSelectedEmail
                          select x).First();

        dbcon.EmailTables.Remove(app);
        dbcon.SaveChanges();
        Response.Redirect("DoctorMsgsView.aspx");
    }
}