﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;

public partial class EWork_DoctorSearchPatients : System.Web.UI.Page
{
    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }



        dbcon.PatientTables.Load();
        //Load table into page
        GridView1.DataSourceID = null;
        GridView1.DataSource = dbcon.PatientTables.Local;
        GridView1.DataBind();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //add patient ID and username to session
        int patientID = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);
        string patientUN = GridView1.SelectedRow.Cells[7].Text;

        Session.Add("PatientID", patientID);
        Session.Add("PatientUsername", patientUN);

        Response.Redirect("DoctorApptsSelectTime.aspx");

    }

    

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Button2.Visible = true;
    }
}