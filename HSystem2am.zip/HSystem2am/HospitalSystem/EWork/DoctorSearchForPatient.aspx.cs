﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;

public partial class EWork_DoctorSearchForPatient : System.Web.UI.Page
{
    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        //hide apppropriate links
        string userRole = Session["UserType"].ToString();

        //check if user is doctor
        if (userRole.Equals("Doctor"))
        {
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
        }

        else if (userRole.Equals("Patient"))
        {
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;
        }


        dbcon.PatientTables.Load();

        //load table into page
        GridView1.DataSourceID = null;
        GridView1.DataSource = dbcon.PatientTables.Local;
        GridView1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string search = TextBox1.Text;
        //Does not do anything if Textbox1 is empty
        if (search.Equals(""))
            return;

        //Searches PatientTable for patients by ID
        var patient = dbcon.PatientTables.Local.FirstOrDefault();
        try
        {
            patient = dbcon.PatientTables.Local.FirstOrDefault((p) => p.PatientId == Convert.ToInt32(search));
        }
        catch (System.FormatException)
        {
            // patient = dbcontext.PatientTables.Local.FirstOrDefault((p) => p.Name.Contains(search));   //Todo: Select multiple by lastname, lookup SelectMany()
            //var Patient = from tempPatient in dbcontext.PatientTables.Local
            //          where tempPatient.Name.Contains(search)
            //          select tempPatient;
        }

        // patient = dbcontext.PatientTables.Local.FirstOrDefault((p) => p.Name.Contains(search));   //Todo: Select multiple by lastname, lookup SelectMany()
        var Patient = from tempPatient in dbcon.PatientTables.Local
                      where tempPatient.Name.ToLower().Contains(search.ToLower())
                      select tempPatient;

        //Displays in ListBox relevant patients
        if (patient == null)
        {
            //True only if try-catch works but finds no patient
            ListBox1.Items.Clear();
            ListBox1.Items.Add("No patients found.");
        }
        else if (Patient.Any() != false)
        {
            //True only if letter input

            ListBox1.Items.Clear();
            //ListBox1.Items.Add(patient.Name+"; "+patient.PatientUserName);

            List<PatientTable> patientList = Patient.ToList();
            foreach (var person in patientList)
            {
                ListBox1.Items.Add(person.PatientId + "; " + person.Name + "; " + person.PatientUserName);
                //patientList.Remove(person);
            }


            // foreach( var name in Patient)
            // {
            //     ListBox1.Items.Add(Patient.First().Name);
            //     Patient.
            // }
        }
        else
        {
            //True only if patient != null & was not searching by name
            ListBox1.Items.Clear();
            ListBox1.Items.Add(patient.PatientId + "; " + patient.Name + "; " + patient.PatientUserName);
        }
    }



}