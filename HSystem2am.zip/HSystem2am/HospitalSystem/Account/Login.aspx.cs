﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using HospitalSystem;
using System.Linq;

public partial class Account_Login : Page
{
        protected void Page_Load(object sender, EventArgs e)
        {
            //RegisterHyperLink.NavigateUrl = "Register";
            OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
            var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            if (!String.IsNullOrEmpty(returnUrl))
            {
                //RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            }

        //hide all nav links
        //hide apppropriate links
        
            this.Master.FindControl("li_PAppts").Visible = false;
            this.Master.FindControl("li_DAppts").Visible = false;
            this.Master.FindControl("li_PatientSearch").Visible = false;
            this.Master.FindControl("li_Home").Visible = false;
            this.Master.FindControl("li_Msgs").Visible = false;
            this.Master.FindControl("li_MsgsD").Visible = false;

    }

    HospitalSystemDatabaseEntities dbcon = new HospitalSystemDatabaseEntities();

        protected void LogIn(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user password
                var manager = new UserManager();
                ApplicationUser user = manager.Find(UserName.Text, Password.Text);
                if (user != null)
                {

                //Add current username to session - used to validate what infomation to view
                //Yes, this is terrible security practice

                //check if UserName is contained w/in either doctor or patient tables
                bool patientTruth = dbcon.PatientTables.Where(type => type.PatientUserName.Equals(UserName.Text)).Any();
                bool doctorTruth = dbcon.DoctorTables.Where(type => type.DoctorUserName.Equals(UserName.Text)).Any();

                //grab username
                //save username to session
                Session.Add("Username", UserName.Text);
                string username = Session["Username"].ToString();

                

                if (patientTruth)
                {
                    Session.Add("UserType", "Patient");

                    var result = (from x in dbcon.PatientTables
                                  where x.PatientUserName.Equals(username)
                                  select x).First();

                    int docID = result.DoctorId;

                    var result2 = (from x in dbcon.DoctorTables
                                   where x.DoctorId == docID
                                   select x).First();

                    Session.Add("PatientID", result.PatientId);
                    Session.Add("DoctorID", result.DoctorId);
                    Session.Add("DoctorUsername", result2.DoctorUserName);
                    Session.Add("PatientUsername", result.PatientUserName);

                    
                }
                else if (doctorTruth)
                {
                    Session.Add("UserType", "Doctor");

                    Session.Add("DoctorUsername", username);

                    string un = Session["Username"].ToString();

                    var result2 = (from x in dbcon.DoctorTables
                                   where x.DoctorUserName.Equals(un)
                                   select x).First();

                    Session.Add("DoctorID", result2.DoctorId);



                }
                else
                {
                    Session.Add("UserType", "Unknown");
                }

                //Session.Add("Username", UserName.Text);
                //Roses are red,
                //Violets are blue,
                //If you hardcore your tokens,
                //I'll use them too!

               
                IdentityHelper.SignIn(manager, user, RememberMe.Checked);
                //IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);

                Response.Redirect("~/EWork/Home.aspx");

                }
                else
                {
                    FailureText.Text = "Invalid username or password.";
                    ErrorMessage.Visible = true;
                }
            }
        }
}